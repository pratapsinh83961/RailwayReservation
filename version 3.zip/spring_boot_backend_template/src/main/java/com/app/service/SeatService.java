package com.app.service;

import com.app.dto.SeatDTO;
import com.app.entity.Seat;

public interface SeatService {

	SeatDTO addnewSeat(SeatDTO seat);
}
