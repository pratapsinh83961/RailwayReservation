package com.app.entity;

public enum Role {
    ADMIN,
    CUSTOMER
}
