package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entity.Train_Station;

public interface Train_StationDao extends JpaRepository<Train_Station, Long> {

}
