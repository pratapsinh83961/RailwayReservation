package com.app.service;

import com.app.dto.Train_StationDTO;
import com.app.entity.Train_Station;

public interface Train_StationService {

	Train_StationDTO addnewTrainStation(Train_StationDTO train_Station );
}
